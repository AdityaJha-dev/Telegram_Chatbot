from fastapi import FastAPI, Form, Request, Response, File, Depends, HTTPException, status
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.encoders import jsonable_encoder
import uvicorn
import os
import aiofiles
import json
import csv
# Ensure src module is found
from src.helper import llm_pipeline

app = FastAPI()

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/upload")
async def chat(request: Request, pdf_file: bytes = File(), filename: str = Form(...)):
    base_folder = 'static/docs/'
    if not os.path.exists(base_folder):
        os.makedirs(base_folder)
    
    pdf_filename = os.path.join(base_folder, filename)

    async with aiofiles.open(pdf_filename, 'wb') as f:
        await f.write(pdf_file)

    return {"msg": "success", "pdf_filename": pdf_filename}


def get_csv(file_path):
    # This calls the heavy lifting LLM pipeline
    answer_generation_chain, ques_list = llm_pipeline(file_path)
    
    base_folder = 'static/output/'
    if not os.path.exists(base_folder):
        os.makedirs(base_folder)
        
    output_file = base_folder + "QA.csv"
    
    with open(output_file, "w", newline="", encoding="utf-8") as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(["Question", "Answer"]) 

        for question in ques_list:
            if not question.strip(): continue # Skip empty lines
            
            print("Question: ", question)
            # Invoke the chain
            answer = answer_generation_chain.invoke(question)
            print("Answer: ", answer)
            print("--------------------------------------------------\n")

            csv_writer.writerow([question, answer])
            
    return output_file

@app.post("/analyze")
async def chat(request: Request, pdf_filename: str = Form(...)):
    try:
        output_file = get_csv(pdf_filename)
        return {"output_file": output_file}
    except Exception as e:
        print("\n🔥 ERROR IN ANALYZE ENDPOINT 🔥")
        print(str(e))
        print("------------------------------------------------\n")
        raise e   # <-- LET FASTAPI RETURN THE REAL ERROR

if __name__ == "__main__":
    uvicorn.run("app:app", host='127.0.0.1', port=8080, reload=True)