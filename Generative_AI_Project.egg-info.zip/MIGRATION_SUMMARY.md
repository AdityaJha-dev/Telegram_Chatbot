# Migration from OpenAI to HuggingFace — Summary

## What Changed

I've updated the Interview Question Creator to use **open-source LLMs from HuggingFace Hub** instead of OpenAI. Here's what was modified:

### 1. **requirements.txt**
Added HuggingFace packages:
- `langchain-huggingface` — LangChain integration with HF endpoints
- `huggingface-hub` — SDK for HuggingFace API

### 2. **src/helper.py** (main changes)

#### Imports
- ❌ Removed: `ChatOpenAI`, `OpenAIEmbeddings` (OpenAI-specific)
- ✅ Added: `HuggingFaceEndpoint`, `HuggingFaceEmbeddings` (from `langchain_huggingface`)

#### Environment Setup
- Changed from `OPENAI_API_KEY` to `HF_API_KEY`
- Loads HuggingFace token from `.env` file

#### Model Configuration (Lines 22–32)
Three **easy-to-edit** constants at the top:
```python
QUESTION_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"  # Edit this!
ANSWER_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"    # Edit this!
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"  # Edit this!

QUESTION_GEN_TEMPERATURE = 0.3
ANSWER_GEN_TEMPERATURE = 0.1
```

#### LLM Instantiation
- ❌ Old: `ChatOpenAI(temperature=0.3, model="gpt-3.5-turbo")`
- ✅ New: `HuggingFaceEndpoint(repo_id=QUESTION_GEN_MODEL, temperature=..., model_kwargs={...})`

#### Embeddings
- ❌ Old: `OpenAIEmbeddings()`
- ✅ New: `HuggingFaceEmbeddings(model_name=EMBEDDINGS_MODEL)`

#### Tokenizer
- Changed from `gpt-3.5-turbo` → `gpt2` (open-source tokenizer for TokenTextSplitter)

### 3. **.github/copilot-instructions.md**
Updated with HuggingFace-specific guidance:
- How to set `HF_API_KEY` in `.env`
- Which three variables to edit for model selection
- Common model examples and their use cases
- Troubleshooting for HF-specific issues

### 4. **New File: HUGGINGFACE_MODELS.md**
Quick reference guide with:
- Recommended models for question gen, answer gen, and embeddings
- Performance/quality trade-offs
- Setup instructions (token acceptance, .env config)
- Pre-made configurations (fast, balanced, high-quality)

---

## How to Use

### Step 1: Set up `.env`
```
HF_API_KEY=hf_xxxxxxxxxxxxxxxxxxxxx
```
Get token from: https://huggingface.co/settings/tokens

### Step 2: Pick a model
Open `src/helper.py` and edit these 3 lines (27-29):
```python
QUESTION_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"  # ← Change here
ANSWER_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"    # ← Change here
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"  # ← Change here
```

See `HUGGINGFACE_MODELS.md` for recommendations and examples.

### Step 3: Install and run
```bash
pip install -r requirements.txt
python app.py
```

Visit `http://localhost:8080` and upload a PDF!

---

## Model Recommendations

**🎯 Best for most users (balanced speed & quality):**
```python
QUESTION_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"
ANSWER_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
```

**⚡ Fastest (for testing):**
```python
QUESTION_GEN_MODEL = "google/flan-t5-base"
ANSWER_GEN_MODEL = "google/flan-t5-base"
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
```

**🏆 Highest quality (slower):**
```python
QUESTION_GEN_MODEL = "meta-llama/Llama-2-13b-chat-hf"
ANSWER_GEN_MODEL = "meta-llama/Llama-2-7b-chat-hf"
EMBEDDINGS_MODEL = "sentence-transformers/all-mpnet-base-v2"
```

For full list, see `HUGGINGFACE_MODELS.md`.

---

## What's the Same?

- ✅ No changes to `app.py` — web server works as before
- ✅ No changes to `src/prompt.py` — prompts unchanged
- ✅ No changes to `templates/index.html` — UI works as before
- ✅ Data flow is identical: upload → generate questions → answer via FAISS → download CSV

---

## Troubleshooting

**"Model not found"**
→ Check model name on https://huggingface.co/models, try `google/flan-t5-base` first

**"Unauthorized"**
→ Verify `HF_API_KEY` in `.env`, check token is readable

**"ImportError: cannot import name 'HuggingFaceEndpoint'"**
→ Run `pip install -r requirements.txt` again

**Slow responses**
→ Try `google/flan-t5-base` or adjust `max_new_tokens` in `src/helper.py`

See `HUGGINGFACE_MODELS.md` for more troubleshooting.

---

## Benefits

✨ **No API costs** — HuggingFace Inference API is free with rate limits  
✨ **Full control** — Choose any open-source model on HuggingFace Hub  
✨ **Privacy** — No data sent to OpenAI  
✨ **Flexibility** — Easily swap models by editing 3 lines  

Enjoy! 🚀
